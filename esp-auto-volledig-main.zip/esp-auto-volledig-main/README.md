# esp-auto-volledig
Deze code zal gebruikt worden op de esp die zich op de auto bevindt
Deze zal de afstand bepalen tot de "stralingslocatie" en deze publishen op de broker
indien de auto zich dicht genoeg bevindt en op de drukknop geduwd wordt een slot geopend worden
bovendien zal de afstand onder de auto gemeten worden met een ultrasone sensor zodat, we weten wanneer deze wordt opgenomen.
Indien dit zo is zal een buzzer geactiveerd worden en rssi waarde 200 gepubliceerd worden zodat ook de ledbar gedeactiveerd wordt.
